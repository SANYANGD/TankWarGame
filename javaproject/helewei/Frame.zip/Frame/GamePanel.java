package Frame;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import MapEditor.MapElement;
import MapEditor.MapElementBrick;
import MapEditor.PanelMain;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;

import Model.*;
public class GamePanel extends JPanel implements KeyListener{
	private Tank tank;
	//private Blood blood;
	private Bullet bullet=null;
	//private PanelMain panelMain;
	 ChangeDirection1 changeDirection1;
	private ArrayList pbullets =new ArrayList();
	private ArrayList abullets =new ArrayList();
	private ArrayList bloods=new ArrayList();
	//private ArrayList<AutoTank> autoTank=new ArrayList<AutoTank>();
	private ArrayList autoTanks=new ArrayList();
	private static List<MapElement> walls=new ArrayList<MapElement>();
	MapElement m=null;
	private static List<MapElementBrick> bricks=new ArrayList<MapElementBrick>();
	private ArrayList<Boom> Booms=new ArrayList();
	private static Map map = new Map();
	private int tankCoolTime = 0;
	private int score=0;
	private MainFrame frame;
	private int bulletCoolTime = 1;
	private JLabel label1;
	private JLabel label2;
	public GamePanel(MainFrame frame) throws IOException{
		this.frame = frame;
		setSize(800,600);
		addListener();
		tank = new PlayerTank();
		tank.setX(map.getMainPoint().x);
		tank.setY(map.getMainPoint().y);
		Thread t = new FreshThread();
		t.start();
		getwalls();
	}
//	public GamePanel(MainFrame frame, int level, PlayType playType) {
//		this.frame = frame;
//		frame.setSize(775, 600);
//		//this.setSize(775, 600);
//		this.level = level;
//		this.playtype = playType;
//		this.addKeyListener(new KeyMonitor());
//		tank.setX(map.getMainPoint().x);
//		tank.setY(map.getMainPoint().y);
//		//System.out.println(this.level+","+level);
////		if(this.level!=1) {
////			botCount+=level*10;
////		}
//		//setBackground(Color.BLACK);// ���ʹ�ú�ɫ����
//		//init();// ��ʼ�����
//		Thread t = new FreshThread();// ������Ϸ֡ˢ���̣߳���һ������Ҫ���������Ļ���Ϸ�Ῠס
//		t.start();// �����߳�
//		//new AudioPlayer(AudioUtil.START).new AudioThread().start();// ���ű�����Ч
//	//	addListener();// ��������
//	}
	public static List<MapElement> getwalls() throws IOException {
		walls = map.getWalls(walls);
		return walls;
	}
	private Image offScreenImage = null;
	private Graphics gOffScreen = null;
	public void paint(Graphics g){
		if(offScreenImage==null){
			offScreenImage = this.createImage(800,600);
			gOffScreen = offScreenImage.getGraphics();
		}
		super.paint(gOffScreen);
		gOffScreen.setColor(Color.BLACK);
		gOffScreen.fillRect(0,0,800,600);
		for(int i=0;i<autoTanks.size();i++){
			AutoTank a = (AutoTank)autoTanks.get(i);
			a.draw(gOffScreen);
		}
		tank.draw(gOffScreen);
		/*for(int i=0;i<bloods.size();i++) {
			Blood b=(Blood)bloods.get(i);
			b.draw(gOffScreen);
		}*/
		for(int i=0;i<pbullets.size();i++){
			Bullet a = (Bullet)pbullets.get(i);
			a.draw(gOffScreen);
		}
		for(int i=0;i<walls.size();i++){
			MapElement	m = (MapElement)walls.get(i);
				m.draw(gOffScreen);
		}
		for(int i=0;i<abullets.size();i++){
			Bullet a = (Bullet)abullets.get(i);
			a.draw(gOffScreen);
		}
		for(int i=0;i<Booms.size();i++){
			Boom b = (Boom)Booms.get(i);
			if(b.Alive()) {
			b.draw(gOffScreen);
			}
		else {
			Booms.remove(b);
		}
		}
		g.drawImage(offScreenImage,0,0,null);
	}
	private boolean hitboard(Tank obj){
		if(obj.getX()>obj.getBounds().width/2&&obj.getX()<800-obj.getBounds().width/2&&
				obj.getY()>obj.getBounds().height/2&&obj.getY()<600-obj.getBounds().height/2)
			return false;
		else
			return true;
		
	}
	private class FreshThread extends Thread{
		public void run(){
			while(true){
				try{
					Thread.sleep(20);
					tank.go();
					for(int i=0;i<pbullets.size();i++) {
						Bullet p=(Bullet)pbullets.get(i);
						for(int j=0;j<walls.size();j++) {
							MapElement e=(MapElement)walls.get(i);
							if(p.hit(e.getBounds())&&e.getType()=="BASE")
							{
								tank.lifebar();
								break;
							}
						}
					}
					for(int i=0;i<pbullets.size();i++){
						Bullet a = (Bullet)pbullets.get(i);
						if(hitboard(a)) {
							pbullets.remove(a);
							Booms.add(new Boom(a.getX(),a.getY()));
							continue;
						}
						for(int j=0;j<autoTanks.size();j++) {
							AutoTank b = (AutoTank)autoTanks.get(j);
							if(a.getBounds().intersects(b.getBounds())) {
								autoTanks.remove(b);
								pbullets.remove(a);
								Booms.add(new Boom(a.getX(),a.getY()));
								score++;
								//continue;
							}
						}
						a.go();
					}
					if(score==5)
					{
						tank.gamebar();
						break;
					}
					for(int i=0;i<autoTanks.size();i++){
						 AutoTank a = (AutoTank)autoTanks.get(i);
						a.go(tank, a);
						       Bullet b = a.fire();
						       if(b != null) {
						    	   abullets.add(b);
						       }
					}
					for(int i=0;i<abullets.size();i++){
						Bullet a = (Bullet)abullets.get(i);
						a.go();
					}
					repaint();
					for(int i=0;i<pbullets.size();i++){
						for(int j=0;j<abullets.size();j++){
							Bullet p=(Bullet)pbullets.get(i);
							Bullet a=(Bullet)abullets.get(j);
							if(p.hit(a.getBounds()))
							{
								Booms.add(new Boom(a.getX(),a.getY()));
								abullets.remove(a);
								pbullets.remove(p);
								continue;
							}
						}
					}
					for(int i=0;i<autoTanks.size();i++){
						AutoTank a = (AutoTank)autoTanks.get(i);
						if(!hitboard(a)) {
							a.go();
						}
						Bullet b = a.fire();
						if(b != null) {
							abullets.add(b);
						}
					}
					for(int i=0;i<autoTanks.size();i++){
				    	AutoTank a=(AutoTank)autoTanks.get(i);
				    	if(tank.hit(a.getBounds()))
				    	{
				    		Booms.add(new Boom(a.getX(),a.getY()));
				    		autoTanks.remove(a);
				    		tank.setlife(tank.getlife()-1);
				    		//continue;
				    	}
				    	a.go();
				    }
					for(int i=0;i<abullets.size();i++){
						Bullet b = (Bullet)abullets.get(i);
						if(hitboard(b)){
							Booms.add(new Boom(b.getX(),b.getY()));
							abullets.remove(b);
							continue;
						}									
						b.go();
					}
					repaint();
					for(int i=0;i<abullets.size();i++){
						Bullet b=(Bullet)abullets.get(i);
						if(b.hit(tank.getBounds())){
							Booms.add(new Boom(b.getX(),b.getY()));
							abullets.remove(b);
							continue;
						}
						b.go();
						if(b.hit(tank.getBounds()))
						{
							tank.setlife(tank.getlife()-1);
							abullets.remove(b);
							Booms.add(new Boom(tank.getX(),tank.getY()));
							//continue;
						}
					}
					if(tank.getlife()==0)
					{
						tank.lifebar();
						break;
					}
					repaint();
					for(int i=0;i<pbullets.size();i++)
					{
						Bullet p=(Bullet)pbullets.get(i);
						for(int j=0;j<walls.size();j++)
						{
							if(walls.get(j)!=null)
							{
								MapElement e=(MapElement)walls.get(j);
								if(p.hit(e.getBounds())&&e.getType()=="BRICK")
								{
									Booms.add(new Boom(e.getX(),e.getY()));
									pbullets.remove(p);
									walls.remove(e);
									continue;
								}
								else if(p.hit(e.getBounds())&&e.getType()=="IRON")
								{
									Booms.add(new Boom(p.getX(),p.getY()));
									pbullets.remove(p);
									continue;
								}
							}
						}
						p.go();
					}
					repaint();
					for(int i=0;i<abullets.size();i++)
					{
						Bullet a=(Bullet)abullets.get(i);
						for(int j=0;j<walls.size();j++)
						{
							if(walls.get(j)!=null)
							{
								MapElement e=(MapElement)walls.get(j);
								if(a.hit(e.getBounds())&&e.getType()=="BRICK")
								{
									Booms.add(new Boom(e.getX(),e.getY()));
									abullets.remove(a);
									walls.remove(e);
									continue;
								}
								else if(a.hit(e.getBounds())&&e.getType()=="IRON")
								{
									Booms.add(new Boom(e.getX(),e.getY()));
									abullets.remove(a);
									continue;
								}
								else if(a.hit(e.getBounds())&&e.getType()=="BASE")
								{
									Booms.add(new Boom(e.getX(),e.getY()));
									abullets.remove(a);
									walls.remove(e);
									continue;
								}
							}
						}
						a.go();
					}
					repaint();
					for(int i=0;i<walls.size();i++)
					{
						if(walls.get(i)!=null)
						{
							MapElement e=(MapElement)walls.get(i);
							switch(tank.getDirection())
							{
							case 1:
								if(tank.hit(e.getBounds())&&e.getType()!="GRASS")
								{
									tank.setVelocity(0);
								}
								break;
							case 2:
								if(tank.hit(e.getBounds())&&e.getType()!="GRASS")
								{
									tank.setVelocity(0);
								}
								break;
							case 3:
								if(tank.hit(e.getBounds())&&e.getType()!="GRASS")
								{
									tank.setVelocity(0);
								}
								break;
							case 4:
								if(tank.hit(e.getBounds())&&e.getType()!="GRASS")
								{
									tank.setVelocity(0);
								}
								break;
							}
						}
					}
					/*for(int i=0;i<walls.size();i++)
					{
						if(walls.get(i)!=null)
						{
							MapElement e=(MapElement)walls.get(i);
							if(tank.hit(e.getBounds())&&tank.getDirection()==1&&e.getType()!="GRASS")
							{
								tank.setDirection(3);
							}
						   
						}
						else{
							tank.go();
						}
					}
					for(int i=0;i<walls.size();i++)
					{
						if(walls.get(i)!=null)
						{
							MapElement e=(MapElement)walls.get(i);
							if(tank.hit(e.getBounds())&&tank.getDirection()==2&&e.getType()!="GRASS")
							{
								tank.setDirection(4);
							}
							
						}
						else {
							tank.go();
						}
					}
					for(int i=0;i<walls.size();i++)
					{
						if(walls.get(i)!=null)
						{
							MapElement e=(MapElement)walls.get(i);
							if(tank.hit(e.getBounds())&&tank.getDirection()==3&&e.getType()!="GRASS")
							{
								tank.setDirection(1);
							}
							
						}
						else {
							tank.go();
						}
					}
					for(int i=0;i<walls.size();i++)
					{
						if(walls.get(i)!=null)
						{
							MapElement e=(MapElement)walls.get(i);
							if(tank.hit(e.getBounds())&&tank.getDirection()==4&&e.getType()!="GRASS")
							{
								tank.setDirection(2);
							}
							
						}
						else {
							tank.go();
						}
					}*/
					for(int i=0;i<autoTanks.size();i++)
					{
						AutoTank a=(AutoTank)autoTanks.get(i);
						for(int j=0;j<walls.size();j++)
						{
							if(walls.get(j)!=null)
							{
								MapElement e=(MapElement)walls.get(j);
								if(a.hit(e.getBounds())&&a.getDirection()==1)
								{
									a.setDirection(3);
								}
								if(a.hit(e.getBounds())&&a.getDirection()==2)
								{
									a.setDirection(4);
								}
								if(a.hit(e.getBounds())&&a.getDirection()==3)
								{
									a.setDirection(1);
								}
								if(a.hit(e.getBounds())&&a.getDirection()==4)
								{
									a.setDirection(2);
								}
								else {
									a.go();
								}
							}
						}
					}
					if(tankCoolTime==50){
					 AutoTank aTank = new AutoTank();
						Random random = new Random();
						int i = random.nextInt(3);//up
						aTank.setX(map.getPoints()[i].x);
						aTank.setY(map.getPoints()[i].y);
						autoTanks.add(aTank);
						tankCoolTime=0;
						if(random.nextInt(5) == 1){
							ChangeDirection1 change = new ChangeDirection1();
							change.setTank(tank);
							aTank.setStrategy(change);
						}
						else {
							ChangeDirection2 change = new ChangeDirection2();
							change.setTank(tank);
							aTank.setStrategy(change);
						}
					}else{
						tankCoolTime++;
					}
					
				}catch(InterruptedException e){
					e.printStackTrace();				
				}
			}
		}
	}
	private void addListener() {
		frame.addKeyListener(this);// ������������̼�����������ʵ��KeyListener�ӿ�
	}
	@Override
		public void keyPressed(KeyEvent e){
			int key = e.getKeyCode();
			switch(key){
				case KeyEvent.VK_UP:
					tank.setDirection(1);
					break;
				case KeyEvent.VK_RIGHT:
					tank.setDirection(2);
					break;
				case KeyEvent.VK_DOWN:
					tank.setDirection(3);
					break;
				case KeyEvent.VK_LEFT:
					tank.setDirection(4);
					break;
				case KeyEvent.VK_SPACE:
//					if(bulletCoolTime == 2) {
//						Bullet bullet = new Bullet();
//						bullet.setX(tank.getX());
//						bullet.setY(tank.getY());
//						bullet.setDirection(tank.getDirection());
//						bullets.add(bullet);
//						bulletCoolTime =0 ;
//					}
//					else {
//						bulletCoolTime++;
//					Bullet b =tank.fire()
					 Bullet b =tank.fire();
				        if(b != null)
						pbullets.add(b);
//					
			};
			repaint();
		}
	
@Override
public void keyReleased(KeyEvent e) {
	// ��ʵ�ִ˷�����������ɾ��
}

/**
 * ����ĳ�����¼�
 */
@Override
public void keyTyped(KeyEvent e) {
	// ��ʵ�ִ˷�����������ɾ��
}

}

