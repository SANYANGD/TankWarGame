package Frame;

import MapEditor.PanelMain;
import Model.Tank;

public class CrashCheck {
	public  PanelMain panelMain;
    private boolean upCrash=true;
    private boolean rightCrash=true;
    private boolean downCrash=true;
    private boolean leftCrash=true;
	private Tank p;
    public CrashCheck(Tank p,PanelMain panelMain)
    {
    	this.p=p;
    	this.panelMain=panelMain;
    	for(int i=0;i<panelMain.returnMapElementList().size();i++)
    	{
    		if(p.getDirection()==1)
    		{
    			if(p.getX()<-1||p.getX()>771||p.getY()<0||p.getY()>581||
    					(panelMain.returnMapElementList().get(i).getX()-p.getX())<29
    					&&(panelMain.returnMapElementList().get(i).getX()-p.getX())>-14
    					&&(panelMain.returnMapElementList().get(i).getY()-p.getY())>-17
    					&&(panelMain.returnMapElementList().get(i).getY()-p.getY())<0
    					&&(panelMain.returnMapElementList().get(i).getX()-p.getX())!=0
    				)
    			{
    				upCrash=false;
    				break;
    			}
    			else 
    			{
    				upCrash=true;
    			}
    		}
    		else if(p.getDirection()==2)
    		{
    			if(p.getX()<-1||p.getX()>778||p.getY()>581||p.getY()<-1||
    					(panelMain.returnMapElementList().get(i).getX()-p.getX())<28
    					&&(panelMain.returnMapElementList().get(i).getX())>-14
    					&&(panelMain.returnMapElementList().get(i).getY())>0
    					&&(panelMain.returnMapElementList().get(i).getY())<30
    					&&(panelMain.returnMapElementList().get(i).getX()-p.getX())!=0
    					)
    			{
    				rightCrash=false;
    				break;
    			}
    			else
    			{
    				rightCrash=true;
    			}
    		}
    		else if(p.getDirection()==3)
    		{
    			if(p.getX()<-1||p.getX()>771||p.getY()>580||p.getY()<-1||
    					(panelMain.returnMapElementList().get(i).getX()-p.getX())<29
    					&&(panelMain.returnMapElementList().get(i).getX())>-14
    					&&(panelMain.returnMapElementList().get(i).getY())>0
    					&&(panelMain.returnMapElementList().get(i).getY())<30
    					&&(panelMain.returnMapElementList().get(i).getX()-p.getX())!=0
    					)
    			{
    				downCrash=false;
    				break;
    			}
    			else
    			{
    				downCrash=true;
    			}
    		}
    		else if(p.getDirection()==4)
    		{
    			if(p.getX()<-1||p.getX()>778||p.getY()>581||p.getY()<-1||
    					(panelMain.returnMapElementList().get(i).getX()-p.getX())<27
    					&&(panelMain.returnMapElementList().get(i).getX())>-14
    					&&(panelMain.returnMapElementList().get(i).getY())>0
    					&&(panelMain.returnMapElementList().get(i).getY())>-15
    					&&(panelMain.returnMapElementList().get(i).getX()-p.getX())!=0
    					)
    			{
    				leftCrash=false;
    				break;
    			}
    			else
    			{
    				leftCrash=true;
    			}
    		}
    	}
    }
    public boolean getupCrash()
    {
    	return upCrash;
    }
    public boolean getrightCrash()
    {
    	return rightCrash;
    }
    public boolean getdownCrash()
    {
    	return downCrash;
    }
    public boolean getleftCrash()
    {
    	return leftCrash;
    }
}
