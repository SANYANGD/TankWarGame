package Util;

import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import MapEditor.*;
public class MapIO {
	
	public static  void saveMap(File file,List<MapElement> elementList) throws FileNotFoundException {
		Map<String,String> map = new HashMap<String,String>();
		for(int i=0;i<elementList.size();i++) {
			String type = elementList.get(i).getType();	
			String value = map.get(type);
			if(value != null) {
				value = value + elementList.get(i);
			}else {
				value = elementList.get(i).toString();
			}
				
			map.put(type, value);
		}
	
		OutputStream out = new FileOutputStream(file);
		OutputStreamWriter writer = new OutputStreamWriter(out);
		BufferedWriter bw = new BufferedWriter(writer);
		PrintWriter pw = new PrintWriter(bw,true);
		
		Set<String> sets = map.keySet();//���ؼ���set����
		for(String str: sets) {//����ÿһ����ֵ
			System.out.println(map.get(str));//���ؼ�ֵ��Ӧ��value
			pw.println(str + "="+map.get(str));
		}

		pw.close();
	}
	public static List<MapElement> openMap(File file,List<MapElement> elementList) throws IOException{
		/*JFileChooser jfc=new JFileChooser();
		jfc.showOpenDialog(jfc);
		file=jfc.getSelectedFile();
		try {
			if(file!=null) {
				FileInputStream in=new FileInputStream(file);
				InputStreamReader ipr = new InputStreamReader(in, "GBK");
                BufferedReader bf = new BufferedReader(ipr);
                JTextArea jt= new JTextArea();
                String str = "";
                while((str=bf.readLine()) != null) {
                       jt.append(str);
                }
			}
			}catch (FileNotFoundException e) {
                System.out.println("���ļ�ʧ��");
         }catch (IOException e) {
                System.out.println("���ļ�ʧ��");
         }*/
		String lines;
		List<String> list=new ArrayList<String>();
		List<MapElement> load=new ArrayList<MapElement>();
		FileReader filereader=new FileReader(file);
		BufferedReader bufferedreader= new BufferedReader(filereader);
		while((lines=bufferedreader.readLine())!=null)
		{
			list.add(lines);
		}
	    bufferedreader.close();
	    for(int i=0;i<list.size();i++)
	    {
	    	String singlelist=list.get(i);
	    	if(singlelist!="")
	    	{
	    		String[] item=new String[1];
	    		item=singlelist.split(",|;|=");
	    		int j;
	    		for(j=0;j<item.length;j++)
	    		{
	    			if(j%2==1)
	    			{
	    				int a=Integer.parseInt(item[j]);
	    				int b=Integer.parseInt(item[j+1]);
	    				MapElement element=new MapElement(a,b);
	    				element=element.setType(item[0],a,b);
	    				load.add(element);
	    			}
	    		}
	    	}
	    }
	    elementList=load;
	    return elementList;
//	    repaint();
		}


}
