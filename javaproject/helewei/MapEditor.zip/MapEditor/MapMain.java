package MapEditor;

import javax.swing.JPanel;

public class MapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FrameMain frame= new FrameMain();
		JPanel panel = new JPanel();
		panel.setSize(800,600);
		
		frame.initFrame();
		
	}

}