package MapEditor;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImgSource {
	private static ImgSource imgs=null;
	private static Image image=null;
	private ImgSource(){
		initImage();
	}
	public static ImgSource getInstance(){
		if(imgs == null){
			imgs = new ImgSource();
		}
		return imgs;
	}
	
	public void initImage(){
		File f = new File("RCYSQYPZ5E_HIA7WI(BHH66.png");
		
		try{
			image = ImageIO.read(f);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
//	public void drawWater(Graphics g,int x,int y){
//		int imagex1,imagey1,imagex2,imagey2;
//		imagex1 = 0;
//		imagey1 = 7*34;
//		imagex2 = imagex1+33;
//		imagey2 = imagey1+33;	
//		g.drawImage(image,
//				x,y,
//				x+33,y+33,
//				imagex1,imagey1,
//				imagex2,imagey2,null);	
//	}
//	public void drawGrass(Graphics g,int x,int y){
//		int imagex1,imagey1,imagex2,imagey2;
//		imagex1 = 4*34;
//		imagey1 = 7*34;
//		imagex2 = imagex1+33;
//		imagey2 = imagey1+33;	
//		g.drawImage(image,
//				x,y,
//				x+33,y+33,
//				imagex1,imagey1,
//				imagex2,imagey2,null);	
//	}
//	public void drawBrick(Graphics g,int x,int y){
//		int imagex1,imagey1,imagex2,imagey2;
//		imagex1 = 18*34;
//		imagey1 = 5*34;
//		imagex2 = imagex1+17;
//		imagey2 = imagey1+17;	
//		g.drawImage(image,
//				x,y,
//				x+17,y+17,
//				imagex1,imagey1,
//				imagex2,imagey2,null);	
//	}
//	public void drawIron(Graphics g,int x,int y){
//		int imagex1,imagey1,imagex2,imagey2;
//		imagex1 = 0;
//		imagey1 = 6*34;
//		imagex2 = imagex1+17;
//		imagey2 = imagey1+17;	
//		g.drawImage(image,
//				x,y,
//				x+17,y+17,
//				imagex1,imagey1,
//				imagex2,imagey2,null);	
//	}
//
//public void drawHome(Graphics g,int x,int y){
//	int imagex1,imagey1,imagex2,imagey2;
//	imagex1 = 19*34;
//	imagey1 = 5*34;
//	imagex2 = imagex1+33;
//	imagey2 = imagey1+33;	
//	g.drawImage(image,
//			x,y,
//			x+33,y+33,
//			imagex1,imagey1,
//			imagex2,imagey2,null);	
//}
//
//public void drawTank1(Graphics g,int x,int y){
//	int imagex1,imagey1,imagex2,imagey2;
//	imagex1 = 0;
//	imagey1 = 0;
//	imagex2 = imagex1+34;
//	imagey2 = imagey1+34;	
//	g.drawImage(image,
//			x,y,
//			x+34,y+34,
//			imagex1,imagey1,
//			imagex2,imagey2,null);	
//}
//public void drawTank2(Graphics g,int x,int y){
//	int imagex1,imagey1,imagex2,imagey2;
//	imagex1 = 0;
//	imagey1 = 34;
//	imagex2 = imagex1+34;
//	imagey2 = imagey1+34;	
//	g.drawImage(image,
//			x,y,
//			x+34,y+34,
//			imagex1,imagey1,
//			imagex2,imagey2,null);	
//}
	public void drawSpade(Graphics g,int x,int y) {
		drawElement(g,x,y,24,7,34);		
	}
	public void drawWater(Graphics g,int x,int y) {
		drawElement(g,x,y,0,7,34);			
	}
	public void drawGrass(Graphics g,int x,int y) {
		drawElement(g,x,y,4,7,34);		
	}
	public void drawBrick(Graphics g,int x,int y) {
		drawElement(g,x,y,18,5,34);			
	}
	public void drawIron(Graphics g,int x,int y) {
		drawElement(g,x,y,0,6,17);			
	}
	public void drawBase(Graphics g,int x,int y) {
		drawElement(g,x,y,19,5,34);	
		
	}
	
	public void drawElement(Graphics g,int x,int y,int imgX,int imgY,int width) {
		
		g.drawImage(image,
				x,y,
				x+width,y+width,
				imgX,imgY,
				imgX+width,imgY+width,null);
	}	
}
