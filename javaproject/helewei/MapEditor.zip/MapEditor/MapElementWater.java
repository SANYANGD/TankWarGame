package MapEditor;

public class MapElementWater extends MapElement{
	private int state=0;
	public MapElementWater(int x,int y) {
		super(x,y);
		imgX = 0;
		imgY = 7*34;
		width = 34;
		type = "WATER";
		pass=true;
		destroy=false;
		boom=false;
	}
	public void follow()
	{
		if(state==0)
		{
		   state=1;	
		}else {
			state=0;
		}
	}
	public MapElement CloneElement(int x,int y) {
		return new MapElementWater(x,y);
	}
}
