package MapEditor;

import java.awt.Rectangle;

public class MapElementBrick extends MapElement{
	public MapElementBrick(int x,int y) {
		super(x,y);
		imgX = 18*34;
		imgY = 5*34;
		width = 17;
		type = "BRICK";
		pass=false;
		destroy=true;
		boom=true;
	}
	public MapElement CloneElement(int x,int y) {
		return new MapElementBrick(x,y);
	}
	/*public Rectangle getBounds(){
		return new Rectangle(imgX-width/2,imgY-width/2,width,width);
	}*/
	/*public void setX(int x){
		this.x = x;
	}
	public int getX(){
		return imgX;
	}
	public void setY(int y){
		this.imgY = y;
	}
	public int getY(){
		return imgY;
	}*/
}
