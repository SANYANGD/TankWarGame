package MapEditor;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Transparency;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;



public class MapElement {
	private int positionX;
	private int positionY;
	protected int imgX;
	protected int imgY;
	protected int width;
	protected String type;
	protected boolean pass=false;
	protected boolean destroy=false;
	protected boolean boom=false;
	public MapElement(int x,int y) {
		this.positionX=x;	
		this.positionY=y;
	}
	public Rectangle getBounds() {
		// ���� һ�������ڣ�x,y��λ�ã�����Ϊ(width,height)�ľ��α߽���󲢷���
		return new Rectangle(positionX,positionY,width,width);
	}
	public boolean hit(Rectangle r) {
		if(r == null) {//���Ŀ��Ϊ��
			return false; //����false,��������ײ
		}
		return getBounds().intersects(r); //�������ߵı߽�����Ƿ��ཻ
	}
	
	public void draw(Graphics g) {				
		ImgSource.getInstance().drawElement(g,positionX,positionY,imgX,imgY,width);	
	}

	public MapElement CloneElement(int x,int y) {
		return null;
	}
	public boolean pointSelect(int x,int y) {
		if(x>positionX && x<positionX+width &&
				y>positionY && y<positionY+width ) {
			return true;
		}else {
			return false;
		}
	}
	public Image getCursor() {
	
		//�����ڴ�ͼ�����
		BufferedImage bufferedImage = new BufferedImage(width, width,BufferedImage.TYPE_INT_RGB);

		Graphics2D g2d = bufferedImage.createGraphics();
		//���ñ���͸��
		bufferedImage = g2d.getDeviceConfiguration().createCompatibleImage(width, width, Transparency.TRANSLUCENT);

		g2d.dispose();
		g2d = bufferedImage.createGraphics();

	
		ImgSource.getInstance().drawElement(g2d,0,0,imgX,imgY,width);
		
		return bufferedImage;
	}
	public String getType() {
		return type;
	}
	public String toString() {
		return positionX + ","+positionY+";";
	}
    public boolean getPass(){
    	return pass;
    }
    public boolean getDestroy(){
    	return destroy;
    }
    public boolean getBoom(){
    	return boom;
    }
public MapElement setType(String Type, int x, int y) {
	// TODO Auto-generated method stub
	MapElement m;
	if(Type.equals("BRICK")) {
		m=new MapElementBrick(x,y);
	}
	else if(Type.equals("BASE")) {
		m=new MapElementBase(x,y);
	}
	else if(Type.equals("AUTOTANK")) {
		m=new MapElementAutoTank(x,y);
	}
	else if(Type.equals("PLAYERTANK")) {
		m=new MapElementPlayerTank(x,y);
	}
	else if(Type.equals("GRASS")) {
		m=new MapElementGrass(x,y);
	}
	else if(Type.equals("IRON")) {
		m=new MapElementIron(x,y);
	}
	else if(Type.equals("WATER")) {
		m=new MapElementWater(x,y);
	}
	else{
		m=new MapElementSpade(x,y);
	}
	return m;
}
public void setX(int x){
	// TODO Auto-generated method stub
	this.positionX=x;
}
public int getX(){
	return positionX;
}
public void setY(int y) {
	// TODO Auto-generated method stub
	this.positionY=y;
}
public int getY(){
	return positionY;
}

}
